### Elliptic Curve Cryptography (ECC)

This script also supports certificates with Elliptic Curve public keys!
Simply set the `KEY_ALGO` variable in one of the config files.
