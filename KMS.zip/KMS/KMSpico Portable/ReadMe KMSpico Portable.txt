Important: If you like MS Windows and MS Office please buy legal and original
			this program help to test this products, but recommend you buy legal from creators (M$ Corp).
			I did this for fun, and now I am done with this. 
			Working in W8 and Office 2013 fresh install and VOLUMEN LICENSE editions.
			Ja mata ne, Farewell, Hejd�, Ciao, Aloha, Zegnaj, Doei

KMSpico v10.2.0 Portable Edition.

- Requirements: .NET 4.0 or Windows 8/8.1/2012/R2.
- Activate: Windows Vista Business/N/Enterprise/N
			Windows 7 Professional/N/Enterprise/N
			Windows 8/8.1
			Windows 10 All
			Office 2010/2013/2016
			Windows Server 2008/Standard/Datacenter/Enterprise/2008R2/Standard/Datacenter/Enterprise/
			Windows Server 2012/Standard/Datacenter/2012R2/Standard/Datacenter
			Windows Server 2016 (Theorically)

1. Run Auto.cmd or Autopico.exe
2. Done.

Based off of open source code KMSEmulator of mikmik38, qad, cynecx, jm287, HotBird64, zm0d, CODYQX4.

Recommendations Optional:

- Make exceptions in anti-virus or Defender to Directory and files in 
%ProgramFiles%\KMSpico\KMSELDI.exe, Service_KMS.exe, Autopico.exe 
also for W10/8/8.1/2012R/2016 the files  %WinDir%\SECOH-QAD.exe.

- In case of troubles check the log files inside "logs" folder.
- Use Volume Licensed products.

File     : AutoPico.exe
Size     : 728,19 KB
CRC32    : f88139fe
MD5      : cfe1c391464c446099a5eb33276f6d57
SHA1     : 9999bfcded2c953e025eabaa66b4971dab122c24

Autopico.exe receive the follow switches:
/silent
/backup
/status
/removewatermark
/restorewatermark

Change Log:
- Fixed bugs with Office 2010 activation in W8.1/W10.
- Add feature to remove the KMS Emulator IP address from products in W8.1/W10 after activation.


+ L E G A L +

First of all you should know that I do NOT release these cracks
so that you "the end-user" can benefit from it in the term of
using software or any other of these releases without buying
the required licenses. heldigard however believe that everyone
should have the option to test and backup their program and be
able to run it without any problems.

Further I do NOT in any way condone the spreading of this
crack, in other words I do NOT spread the releases to any
websites, P2P networks or any other public available location
and I urge that this releases should not be spread like that
at all.

I -heldigard- has nothing to do with the distribution of these
cracks, it is all done by third parties. As such, and
according to the laws where the individuals of heldigard reside,
it is not my responsibility what others decides to do with
these releases. However, let it be said quite clearly;

"I DO NOT in any way condone the selling or redistribution
of these cracks, this was NEVER my intention."

heldigard does NOT take any responsibility of computer-loss
or any data-errors that may occur from using these cracks.
Keep in mind that you are using a third party solution to
something we did not develop in the first place.

Do note that the usage of these cracks are legal in most
countries outside the United States, IF and ONLY IF you own a
full copy of the program - then you may use these cracks
for backup purposes, and only that. It remains to be seen how
affected you are of the End User License Agreements (EULAs).
They can't supersede domestic laws, remember that.

According to the "DMCA ACT" in the Unites States, you have no
rights to circumvent a copy protection. Beware, they will
punish you harder than if you stole the shrinkwrapped software
in a mall. Though heldigard's base of operation does not reside
in the Unites States, and thus I am NOT bound to the
US legislations like:

* No Electronic Theft Act
* Digital Millenium Copyright Act
* The Patriot Act
* "other US legislations"

You should ALWAYS buy the software that you do use, or find
suitable Open Source replacements (as there are loads), I do!

By using these cracks you automatically agree
to the written agreement above, and thus the responsibility
regarding whatever you are affected by any EULAs is
with YOU and YOU only.

+ G R E E T S +

MIKMIK38, RATIBORUS, QAD, ZM0D, CYNECX, ALPHAWAVES
NOSFERATI87, JM287, HOTBIRD64, DEAGLES, CODYQX4, XINSO, NOVEMBER_RA1N
CERBERUS8855, HUI, NOVA-S, KELORGO.

forums.mydigitallife.info
nsaneforums.com
intercambiosvirtuales.org
ru-board.com
pcbeta.com

FAQ

0. Windows Update
Q: Can I install the updates after using this application?
A: Until now yes.

1. SmartScreen
Q: The smart-screen is Gray!, god save all of us, kmspico broke my OS!.
A: If you are enough fool to use SmartScreen, then EnableSmartScreen the reg file in scripts folder.

2. Permanent Activation
Q: It is this permanent?
A: Until now for Windows 6,7,8,8.1 it will automatic reactivate it often, so yes.

3. Pro WMC/Core
Q: It only activate for 30 days or 45 days?
A: It is not possible in real kms activate a ProWMC/Core, but thanks to the emulator is possible activate it for 30 days in W8 and 45 days for W8.1

4. Virus:
Q:My anti-virus alert like crazy!
A:If you downloaded the file from another location, we don't know what other people do with the file. The file here only has false positives.

5. On-line/Off-line:
Q: I need internet connection?
A: No.

6. Evaluation Edition
Q: I can't activate Windows 8.1 only Office, HELP!!!
I'm having problems with activating windows.
The log:

20:13:26:322 Installing Key: -9D6T9 
20:13:26:403 Error: C004E016 InstallProductKey 
20:13:26:562 Error: C004F013 RefreshLicenseStatus 
20:13:26:917 Found Windows Products: 1 
20:13:26:919 Name: Windows(R), Professional edition
Description: Windows(R) Operating System, RETAIL channel
GracePeriodRemaining: 0
LicenseStatus: 0
PartialProductKey: 9Y92F
GenuineStatus: 1

A: If you are using an evaluation version, then install a fresh RTM edition.


7. Firewall AV
Q: Does not Work!!!
A: Some anti-virus block the applications, give the respective exceptions.

8. Hack-activators
Q: Nothing Work!!!
A: Do a fresh install.

9. Watermark
Q: It activate, but the watermark is still there!
A: Reboot.

10. OEM/MAK
Q: I am afraid, my windows/office is genuine/legit activated. Do this application will broke my license? 
A: The application is designed to check a permanent activation either windows or office and avoid it. Older versions was buggy, but the main idea of this app is be smart and take the right choice without any intervention.

11. Log files
Q: Where are the log files of this program?
A: Program Files -> KMSpico -> logs

Demo Videos:

http://www.youtube.com/watch?feature=player_embedded&v=RFdhz4OZDxc

http://www.youtube.com/watch?feature=player_embedded&v=KGtMCLiBPVI
